import flask
from flask import Flask, request, jsonify
from .openai_conn import get_answer_from_gpt


def setup_rest_api(conductor):

    def _corsify(response):
        """ adds CORS headers to response """
        response.headers.add('Access-Control-Allow-Origin', '*')
        if request.method == 'OPTIONS':
            response.headers.add('Access-Control-Allow-Methods', '*')
            headers = request.headers.get('Access-Control-Request-Headers')
            if headers is not None:
                response.headers.add('Access-Control-Allow-Headers', headers)
        return response



    @conductor.app.errorhandler(400)
    def _bad_request(msg=None):
        """ bad request """
        response = conductor.templates['http_resp'].copy()
        response['action'] = f"{request}"
        response['code'] = '400'
        response['message'] = 'Bad request'
        if msg is not None:
            response['message'] += f': {msg}'
        return _corsify(jsonify(response)), 400


    @conductor.app.errorhandler(404)
    def _page_not_found(exception=None):
        """ page not found """
        response = conductor.templates['http_resp'].copy()
        response['action'] = f"{exception}"
        response['code'] = '404'
        response['message'] = f"Available endpoints: {','.join(conductor.list_endpoints())}"
        return jsonify(response), 404


    @conductor.app.route('/')
    @conductor.app.route('/about')
    def index():
        return "Home"

    
    @conductor.app.route('/openai', methods=['POST'])
    def test():
        json_obj = request.get_json(force=True)
        print(json_obj)
        context = json_obj['context']
        question = json_obj['question']
        prompt = context + ' ' + question
        print(prompt)
        res = get_answer_from_gpt(prompt)
        print(res)
        response = jsonify({"test": res})
        #response.headers.add('Access-Control-Allow-Origin', '*')
        return _corsify(response)


    @conductor.app.route('/about')
    def about():
        return "About"




