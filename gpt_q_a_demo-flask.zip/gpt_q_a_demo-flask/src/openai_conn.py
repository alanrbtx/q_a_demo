import openai    

def get_answer_from_gpt(prompt):
    openai.api_key = "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"


    model_engine = "text-davinci-003"
    #prompt = "Твое имя Лулу. Ты голосовой ассистент для бизнеса. У нас есть 100 курсов по информатике и 50 курсов по биологии. Сколько у вас курсов по информатике и как тебя зовут?"

    completions = openai.Completion.create(
        engine=model_engine,
        prompt=prompt,
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.5,
    )

    # Получаем ответ
    message = completions.choices[0].text
    return message